// Función que se ejecuta cuando se hace clic en el botón
function showMessage() {
    // Muestra una alerta con un mensaje
    alert("¡Gracias por contactarme! Me pondré en contacto contigo pronto.");
}
